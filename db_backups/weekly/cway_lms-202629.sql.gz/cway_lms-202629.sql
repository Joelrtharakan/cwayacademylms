--
-- PostgreSQL database dump
--

\restrict XrNYLkkEPlXm5Tnv7pWq2jkJeG0wbButLhTf95qdujLt0IFWLsEav8usdbdW8p4

-- Dumped from database version 16.14
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: cway
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO cway;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: cway
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ActivityLog; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."ActivityLog" (
    id text NOT NULL,
    "userId" text,
    "actorEmail" text,
    "actorName" text,
    "actorRole" text,
    action text NOT NULL,
    resource text,
    "resourceId" text,
    description text,
    metadata text,
    "ipAddress" text,
    "userAgent" text,
    status text DEFAULT 'SUCCESS'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ActivityLog" OWNER TO cway;

--
-- Name: Announcement; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Announcement" (
    id text NOT NULL,
    "courseId" text NOT NULL,
    "sectionId" text,
    "authorId" text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "isPinned" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Announcement" OWNER TO cway;

--
-- Name: Answer; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Answer" (
    id text NOT NULL,
    "questionId" text NOT NULL,
    text jsonb NOT NULL,
    "isCorrect" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Answer" OWNER TO cway;

--
-- Name: Assignment; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Assignment" (
    id text NOT NULL,
    "lessonId" text NOT NULL,
    title jsonb NOT NULL,
    description jsonb NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "maxScore" integer DEFAULT 100 NOT NULL,
    "attachmentUrl" text,
    "rubricId" text
);


ALTER TABLE public."Assignment" OWNER TO cway;

--
-- Name: AttendanceRecord; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."AttendanceRecord" (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "studentId" text NOT NULL,
    status text DEFAULT 'ABSENT'::text NOT NULL,
    "markedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    note text
);


ALTER TABLE public."AttendanceRecord" OWNER TO cway;

--
-- Name: AttendanceSession; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."AttendanceSession" (
    id text NOT NULL,
    "courseId" text NOT NULL,
    "sectionId" text,
    title text NOT NULL,
    description text,
    "sessionDate" timestamp(3) without time zone NOT NULL,
    "sessionType" text DEFAULT 'LIVE'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AttendanceSession" OWNER TO cway;

--
-- Name: BlogPost; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."BlogPost" (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    excerpt text,
    content text NOT NULL,
    "coverImage" text,
    "coverKey" text,
    "authorId" text NOT NULL,
    "isPublished" boolean DEFAULT false NOT NULL,
    "readingTime" integer,
    "customAuthor" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."BlogPost" OWNER TO cway;

--
-- Name: Category; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Category" (
    id text NOT NULL,
    name jsonb NOT NULL,
    slug text NOT NULL,
    icon text,
    "order" integer DEFAULT 0 NOT NULL,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Category" OWNER TO cway;

--
-- Name: Certificate; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Certificate" (
    id text NOT NULL,
    "studentId" text NOT NULL,
    type text DEFAULT 'COURSE'::text NOT NULL,
    "courseId" text,
    "programId" text,
    "issuedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "uniqueCode" text NOT NULL,
    "certificateNumber" text,
    "downloadUrl" text,
    "templateId" text
);


ALTER TABLE public."Certificate" OWNER TO cway;

--
-- Name: CertificateTemplate; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."CertificateTemplate" (
    id text NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'COURSE'::text NOT NULL,
    "htmlTemplate" text NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "logoUrl" text,
    "signatorySignatureUrl" text,
    "borderStyle" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CertificateTemplate" OWNER TO cway;

--
-- Name: Coupon; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Coupon" (
    id text NOT NULL,
    code text NOT NULL,
    discount double precision NOT NULL,
    type text NOT NULL,
    "maxUses" integer DEFAULT 100 NOT NULL,
    "usedCount" integer DEFAULT 0 NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "courseId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Coupon" OWNER TO cway;

--
-- Name: Course; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Course" (
    id text NOT NULL,
    title jsonb NOT NULL,
    slug text NOT NULL,
    "courseCode" text,
    subtitle jsonb,
    description jsonb,
    thumbnail text,
    "promoVideoUrl" text,
    price double precision DEFAULT 0 NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    level text DEFAULT 'BEGINNER'::text NOT NULL,
    language text DEFAULT 'ENGLISH'::text NOT NULL,
    "moduleNumber" integer,
    "weeksDuration" integer DEFAULT 6 NOT NULL,
    "totalLectures" integer DEFAULT 0 NOT NULL,
    "totalDuration" integer DEFAULT 0 NOT NULL,
    "scriptureRef" text,
    "isFeatured" boolean DEFAULT false NOT NULL,
    "isFree" boolean DEFAULT true NOT NULL,
    requirements jsonb DEFAULT '{}'::jsonb NOT NULL,
    outcomes jsonb DEFAULT '{}'::jsonb NOT NULL,
    "targetAudience" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "welcomeMessage" jsonb,
    "congratsMessage" jsonb,
    tags text DEFAULT '[]'::text NOT NULL,
    "rejectionReason" text,
    "instructorId" text NOT NULL,
    "categoryId" text,
    "programId" text,
    "invitationStatus" text DEFAULT 'UNASSIGNED'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Course" OWNER TO cway;

--
-- Name: CourseInvitation; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."CourseInvitation" (
    id text NOT NULL,
    "courseId" text NOT NULL,
    "instructorId" text NOT NULL,
    "adminNote" text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CourseInvitation" OWNER TO cway;

--
-- Name: Curriculum; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Curriculum" (
    id text NOT NULL,
    "courseId" text NOT NULL,
    overview text,
    objectives text DEFAULT '[]'::text NOT NULL,
    "weeklyPlan" text DEFAULT '[]'::text NOT NULL,
    "assessmentPlan" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Curriculum" OWNER TO cway;

--
-- Name: Discussion; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Discussion" (
    id text NOT NULL,
    "courseId" text NOT NULL,
    "sectionId" text,
    "lessonId" text,
    "authorId" text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "isPinned" boolean DEFAULT false NOT NULL,
    "isLocked" boolean DEFAULT false NOT NULL,
    score integer,
    feedback text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Discussion" OWNER TO cway;

--
-- Name: DiscussionReply; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."DiscussionReply" (
    id text NOT NULL,
    "discussionId" text NOT NULL,
    "authorId" text NOT NULL,
    content text NOT NULL,
    "isInstructor" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DiscussionReply" OWNER TO cway;

--
-- Name: EmailTemplate; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."EmailTemplate" (
    id text NOT NULL,
    name text NOT NULL,
    subject text NOT NULL,
    "htmlBody" text NOT NULL,
    variables text DEFAULT '[]'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailTemplate" OWNER TO cway;

--
-- Name: Enrollment; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Enrollment" (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "courseId" text NOT NULL,
    "enrolledAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    progress double precision DEFAULT 0 NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "paymentId" text,
    "sponsorshipId" text
);


ALTER TABLE public."Enrollment" OWNER TO cway;

--
-- Name: Extension; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Extension" (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "itemId" text NOT NULL,
    "itemType" text NOT NULL,
    "courseId" text NOT NULL,
    "extendedDate" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Extension" OWNER TO cway;

--
-- Name: ExtensionRequest; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."ExtensionRequest" (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "itemId" text NOT NULL,
    "itemType" text NOT NULL,
    "courseId" text NOT NULL,
    reason text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "requestedDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ExtensionRequest" OWNER TO cway;

--
-- Name: Forum; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Forum" (
    id text NOT NULL,
    "courseId" text NOT NULL
);


ALTER TABLE public."Forum" OWNER TO cway;

--
-- Name: ForumPost; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."ForumPost" (
    id text NOT NULL,
    "forumId" text NOT NULL,
    "authorId" text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "isPinned" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ForumPost" OWNER TO cway;

--
-- Name: ForumReply; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."ForumReply" (
    id text NOT NULL,
    "postId" text NOT NULL,
    "authorId" text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ForumReply" OWNER TO cway;

--
-- Name: Lesson; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Lesson" (
    id text NOT NULL,
    "sectionId" text NOT NULL,
    title jsonb NOT NULL,
    type text NOT NULL,
    content jsonb,
    "videoUrl" text,
    duration integer DEFAULT 0 NOT NULL,
    "order" integer NOT NULL,
    "isFree" boolean DEFAULT false NOT NULL,
    "isPreview" boolean DEFAULT false NOT NULL,
    "bunnyVideoId" text,
    "forumMarks" integer,
    "dueDate" timestamp(3) without time zone
);


ALTER TABLE public."Lesson" OWNER TO cway;

--
-- Name: LessonProgress; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."LessonProgress" (
    id text NOT NULL,
    "enrollmentId" text NOT NULL,
    "lessonId" text NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "watchedSeconds" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."LessonProgress" OWNER TO cway;

--
-- Name: Message; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "senderId" text NOT NULL,
    "receiverId" text NOT NULL,
    content text NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "readAt" timestamp(3) without time zone
);


ALTER TABLE public."Message" OWNER TO cway;

--
-- Name: Note; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Note" (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "lessonId" text NOT NULL,
    content text NOT NULL,
    "timestamp" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Note" OWNER TO cway;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    link text,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Notification" OWNER TO cway;

--
-- Name: Payment; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "courseId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    "stripePaymentId" text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "isSponsored" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Payment" OWNER TO cway;

--
-- Name: Program; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Program" (
    id text NOT NULL,
    title jsonb NOT NULL,
    description jsonb,
    thumbnail text,
    "thumbnailKey" text,
    duration text,
    tags text DEFAULT '[]'::text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "applicationsClosed" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Program" OWNER TO cway;

--
-- Name: ProgramApplication; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."ProgramApplication" (
    id text NOT NULL,
    "programId" text NOT NULL,
    "mediumOfStudy" text DEFAULT 'English'::text NOT NULL,
    "fullName" text NOT NULL,
    dob timestamp(3) without time zone NOT NULL,
    gender text NOT NULL,
    "maritalStatus" text NOT NULL,
    nationality text NOT NULL,
    "aadhaarNumber" text,
    "passportPhotoUrl" text NOT NULL,
    "mobileNumber" text NOT NULL,
    "whatsappNumber" text NOT NULL,
    email text NOT NULL,
    "permanentAddress" text NOT NULL,
    "currentAddress" text NOT NULL,
    "highestQualification" text NOT NULL,
    "previousInstitution" text NOT NULL,
    "yearOfCompletion" text NOT NULL,
    "marksOrGrade" text NOT NULL,
    "certificatesUrls" text NOT NULL,
    "isBornAgain" boolean NOT NULL,
    "churchName" text NOT NULL,
    "churchAddress" text NOT NULL,
    "pastorName" text NOT NULL,
    "ministryExperience" text,
    "callingStatement" text NOT NULL,
    "reference1Name" text NOT NULL,
    "reference1Email" text,
    "reference1Phone" text NOT NULL,
    "reference1Relation" text NOT NULL,
    "reference1Type" text,
    "reference1Token" text,
    "reference1Status" text DEFAULT 'PENDING'::text NOT NULL,
    "reference2Name" text NOT NULL,
    "reference2Email" text,
    "reference2Phone" text NOT NULL,
    "reference2Relation" text NOT NULL,
    "reference2Type" text,
    "reference2Token" text,
    "reference2Status" text DEFAULT 'PENDING'::text NOT NULL,
    "declarationName" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProgramApplication" OWNER TO cway;

--
-- Name: ProgramEnrollment; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."ProgramEnrollment" (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "programId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "enrolledAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "currentCourseId" text
);


ALTER TABLE public."ProgramEnrollment" OWNER TO cway;

--
-- Name: Question; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Question" (
    id text NOT NULL,
    "quizId" text NOT NULL,
    text jsonb NOT NULL,
    type text DEFAULT 'MCQ'::text NOT NULL,
    points integer DEFAULT 1 NOT NULL,
    "order" integer NOT NULL,
    "scriptureRef" text
);


ALTER TABLE public."Question" OWNER TO cway;

--
-- Name: Quiz; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Quiz" (
    id text NOT NULL,
    "lessonId" text NOT NULL,
    title jsonb NOT NULL,
    "passingScore" integer DEFAULT 70 NOT NULL,
    "timeLimit" integer,
    "maxAttempts" integer DEFAULT 3 NOT NULL,
    "rubricId" text
);


ALTER TABLE public."Quiz" OWNER TO cway;

--
-- Name: QuizAttempt; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."QuizAttempt" (
    id text NOT NULL,
    "quizId" text NOT NULL,
    "studentId" text NOT NULL,
    score double precision DEFAULT 0 NOT NULL,
    passed boolean DEFAULT false NOT NULL,
    answers text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public."QuizAttempt" OWNER TO cway;

--
-- Name: ReadingMaterial; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."ReadingMaterial" (
    id text NOT NULL,
    "sectionId" text NOT NULL,
    title text NOT NULL,
    description text,
    "fileUrl" text NOT NULL,
    "fileKey" text NOT NULL,
    "fileType" text NOT NULL,
    "fileSize" integer NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ReadingMaterial" OWNER TO cway;

--
-- Name: ReadingMaterialProgress; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."ReadingMaterialProgress" (
    id text NOT NULL,
    "enrollmentId" text NOT NULL,
    "readingMaterialId" text NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public."ReadingMaterialProgress" OWNER TO cway;

--
-- Name: ReferenceForm; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."ReferenceForm" (
    id text NOT NULL,
    "applicationId" text NOT NULL,
    "referenceIndex" integer NOT NULL,
    type text NOT NULL,
    "yearsKnown" text NOT NULL,
    "capacityKnown" text,
    "churchEngagement" text,
    "spiritualInfluence" text,
    ratings text NOT NULL,
    "financialAbility" text,
    "financialHelp" text,
    comments text,
    "attentionAreas" text,
    "discussFurther" boolean DEFAULT false NOT NULL,
    recommendation text NOT NULL,
    "refereeName" text NOT NULL,
    "refereePosition" text,
    "churchName" text,
    denomination text,
    address text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    "signatureUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ReferenceForm" OWNER TO cway;

--
-- Name: Review; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Review" (
    id text NOT NULL,
    "courseId" text NOT NULL,
    "studentId" text NOT NULL,
    rating integer NOT NULL,
    comment text,
    "isApproved" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Review" OWNER TO cway;

--
-- Name: Rubric; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Rubric" (
    id text NOT NULL,
    "courseId" text NOT NULL,
    title text NOT NULL,
    description text,
    "totalPoints" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Rubric" OWNER TO cway;

--
-- Name: RubricCriteria; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."RubricCriteria" (
    id text NOT NULL,
    "rubricId" text NOT NULL,
    title text NOT NULL,
    description text,
    "maxPoints" integer NOT NULL,
    "order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."RubricCriteria" OWNER TO cway;

--
-- Name: RubricLevel; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."RubricLevel" (
    id text NOT NULL,
    "criteriaId" text NOT NULL,
    label text NOT NULL,
    description text NOT NULL,
    points integer NOT NULL,
    "order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."RubricLevel" OWNER TO cway;

--
-- Name: Section; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Section" (
    id text NOT NULL,
    "courseId" text NOT NULL,
    title jsonb NOT NULL,
    description jsonb,
    objectives text DEFAULT '[]'::text NOT NULL,
    "weekNumber" integer,
    "isPublished" boolean DEFAULT false NOT NULL,
    "order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."Section" OWNER TO cway;

--
-- Name: SiteSettings; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."SiteSettings" (
    id text NOT NULL,
    "siteName" text DEFAULT 'CWAY Academy'::text NOT NULL,
    "logoUrl" text,
    tagline text,
    "contactEmail" text,
    "contactWhatsApp" text,
    "primaryColor" text DEFAULT '#C9973A'::text NOT NULL,
    "smtpConfig" text,
    "stripeConfig" text,
    "storageConfig" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SiteSettings" OWNER TO cway;

--
-- Name: Sponsorship; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Sponsorship" (
    id text NOT NULL,
    "sponsorName" text NOT NULL,
    "sponsorEmail" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    "stripePaymentId" text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    message text,
    "studentId" text,
    "courseId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Sponsorship" OWNER TO cway;

--
-- Name: Submission; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."Submission" (
    id text NOT NULL,
    "assignmentId" text NOT NULL,
    "studentId" text NOT NULL,
    content text,
    "fileUrl" text,
    "submittedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    grade double precision,
    feedback text,
    "gradedAt" timestamp(3) without time zone,
    "isGraded" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Submission" OWNER TO cway;

--
-- Name: User; Type: TABLE; Schema: public; Owner: cway
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text,
    role text DEFAULT 'STUDENT'::text NOT NULL,
    avatar text,
    bio text,
    phone text,
    church text,
    location text,
    "preferredLanguage" text DEFAULT 'ENGLISH'::text NOT NULL,
    "isVerified" boolean DEFAULT false NOT NULL,
    "isBanned" boolean DEFAULT false NOT NULL,
    "emailVerifyToken" text,
    "resetToken" text,
    "resetTokenExpiry" timestamp(3) without time zone,
    "googleId" text,
    "lastLoginAt" timestamp(3) without time zone,
    "lastLogoutAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "socialLinks" text,
    title text,
    credentials text,
    "yearsExperience" integer,
    expertise text DEFAULT '[]'::text NOT NULL,
    "notificationPrefs" text DEFAULT '{}'::text NOT NULL,
    "appActiveSeconds" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."User" OWNER TO cway;

--
-- Data for Name: ActivityLog; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."ActivityLog" (id, "userId", "actorEmail", "actorName", "actorRole", action, resource, "resourceId", description, metadata, "ipAddress", "userAgent", status, "createdAt") FROM stdin;
\.


--
-- Data for Name: Announcement; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Announcement" (id, "courseId", "sectionId", "authorId", title, content, "isPinned", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Answer; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Answer" (id, "questionId", text, "isCorrect") FROM stdin;
\.


--
-- Data for Name: Assignment; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Assignment" (id, "lessonId", title, description, "dueDate", "maxScore", "attachmentUrl", "rubricId") FROM stdin;
\.


--
-- Data for Name: AttendanceRecord; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."AttendanceRecord" (id, "sessionId", "studentId", status, "markedAt", note) FROM stdin;
\.


--
-- Data for Name: AttendanceSession; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."AttendanceSession" (id, "courseId", "sectionId", title, description, "sessionDate", "sessionType", "createdAt") FROM stdin;
\.


--
-- Data for Name: BlogPost; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."BlogPost" (id, title, slug, excerpt, content, "coverImage", "coverKey", "authorId", "isPublished", "readingTime", "customAuthor", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Category" (id, name, slug, icon, "order", "parentId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Certificate; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Certificate" (id, "studentId", type, "courseId", "programId", "issuedAt", "uniqueCode", "certificateNumber", "downloadUrl", "templateId") FROM stdin;
\.


--
-- Data for Name: CertificateTemplate; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."CertificateTemplate" (id, name, type, "htmlTemplate", "isDefault", "logoUrl", "signatorySignatureUrl", "borderStyle", "createdAt") FROM stdin;
\.


--
-- Data for Name: Coupon; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Coupon" (id, code, discount, type, "maxUses", "usedCount", "expiresAt", "courseId", "isActive", "createdAt") FROM stdin;
\.


--
-- Data for Name: Course; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Course" (id, title, slug, "courseCode", subtitle, description, thumbnail, "promoVideoUrl", price, currency, status, level, language, "moduleNumber", "weeksDuration", "totalLectures", "totalDuration", "scriptureRef", "isFeatured", "isFree", requirements, outcomes, "targetAudience", "welcomeMessage", "congratsMessage", tags, "rejectionReason", "instructorId", "categoryId", "programId", "invitationStatus", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CourseInvitation; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."CourseInvitation" (id, "courseId", "instructorId", "adminNote", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Curriculum; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Curriculum" (id, "courseId", overview, objectives, "weeklyPlan", "assessmentPlan", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Discussion; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Discussion" (id, "courseId", "sectionId", "lessonId", "authorId", title, content, "isPinned", "isLocked", score, feedback, "createdAt") FROM stdin;
\.


--
-- Data for Name: DiscussionReply; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."DiscussionReply" (id, "discussionId", "authorId", content, "isInstructor", "createdAt") FROM stdin;
\.


--
-- Data for Name: EmailTemplate; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."EmailTemplate" (id, name, subject, "htmlBody", variables, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Enrollment; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Enrollment" (id, "studentId", "courseId", "enrolledAt", "completedAt", progress, status, "paymentId", "sponsorshipId") FROM stdin;
\.


--
-- Data for Name: Extension; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Extension" (id, "studentId", "itemId", "itemType", "courseId", "extendedDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ExtensionRequest; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."ExtensionRequest" (id, "studentId", "itemId", "itemType", "courseId", reason, status, "requestedDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Forum; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Forum" (id, "courseId") FROM stdin;
\.


--
-- Data for Name: ForumPost; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."ForumPost" (id, "forumId", "authorId", title, content, "isPinned", "createdAt") FROM stdin;
\.


--
-- Data for Name: ForumReply; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."ForumReply" (id, "postId", "authorId", content, "createdAt") FROM stdin;
\.


--
-- Data for Name: Lesson; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Lesson" (id, "sectionId", title, type, content, "videoUrl", duration, "order", "isFree", "isPreview", "bunnyVideoId", "forumMarks", "dueDate") FROM stdin;
\.


--
-- Data for Name: LessonProgress; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."LessonProgress" (id, "enrollmentId", "lessonId", "completedAt", "watchedSeconds") FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Message" (id, "senderId", "receiverId", content, "sentAt", "readAt") FROM stdin;
\.


--
-- Data for Name: Note; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Note" (id, "studentId", "lessonId", content, "timestamp", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Notification" (id, "userId", type, title, body, link, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Payment" (id, "studentId", "courseId", amount, currency, "stripePaymentId", status, "isSponsored", "createdAt") FROM stdin;
\.


--
-- Data for Name: Program; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Program" (id, title, description, thumbnail, "thumbnailKey", duration, tags, status, "applicationsClosed", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProgramApplication; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."ProgramApplication" (id, "programId", "mediumOfStudy", "fullName", dob, gender, "maritalStatus", nationality, "aadhaarNumber", "passportPhotoUrl", "mobileNumber", "whatsappNumber", email, "permanentAddress", "currentAddress", "highestQualification", "previousInstitution", "yearOfCompletion", "marksOrGrade", "certificatesUrls", "isBornAgain", "churchName", "churchAddress", "pastorName", "ministryExperience", "callingStatement", "reference1Name", "reference1Email", "reference1Phone", "reference1Relation", "reference1Type", "reference1Token", "reference1Status", "reference2Name", "reference2Email", "reference2Phone", "reference2Relation", "reference2Type", "reference2Token", "reference2Status", "declarationName", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProgramEnrollment; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."ProgramEnrollment" (id, "studentId", "programId", status, "enrolledAt", "completedAt", "currentCourseId") FROM stdin;
\.


--
-- Data for Name: Question; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Question" (id, "quizId", text, type, points, "order", "scriptureRef") FROM stdin;
\.


--
-- Data for Name: Quiz; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Quiz" (id, "lessonId", title, "passingScore", "timeLimit", "maxAttempts", "rubricId") FROM stdin;
\.


--
-- Data for Name: QuizAttempt; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."QuizAttempt" (id, "quizId", "studentId", score, passed, answers, "startedAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: ReadingMaterial; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."ReadingMaterial" (id, "sectionId", title, description, "fileUrl", "fileKey", "fileType", "fileSize", "order", "createdAt") FROM stdin;
\.


--
-- Data for Name: ReadingMaterialProgress; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."ReadingMaterialProgress" (id, "enrollmentId", "readingMaterialId", "completedAt") FROM stdin;
\.


--
-- Data for Name: ReferenceForm; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."ReferenceForm" (id, "applicationId", "referenceIndex", type, "yearsKnown", "capacityKnown", "churchEngagement", "spiritualInfluence", ratings, "financialAbility", "financialHelp", comments, "attentionAreas", "discussFurther", recommendation, "refereeName", "refereePosition", "churchName", denomination, address, phone, email, "signatureUrl", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Review; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Review" (id, "courseId", "studentId", rating, comment, "isApproved", "createdAt") FROM stdin;
\.


--
-- Data for Name: Rubric; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Rubric" (id, "courseId", title, description, "totalPoints", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: RubricCriteria; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."RubricCriteria" (id, "rubricId", title, description, "maxPoints", "order") FROM stdin;
\.


--
-- Data for Name: RubricLevel; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."RubricLevel" (id, "criteriaId", label, description, points, "order") FROM stdin;
\.


--
-- Data for Name: Section; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Section" (id, "courseId", title, description, objectives, "weekNumber", "isPublished", "order") FROM stdin;
\.


--
-- Data for Name: SiteSettings; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."SiteSettings" (id, "siteName", "logoUrl", tagline, "contactEmail", "contactWhatsApp", "primaryColor", "smtpConfig", "stripeConfig", "storageConfig", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Sponsorship; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Sponsorship" (id, "sponsorName", "sponsorEmail", amount, currency, "stripePaymentId", status, message, "studentId", "courseId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Submission; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."Submission" (id, "assignmentId", "studentId", content, "fileUrl", "submittedAt", grade, feedback, "gradedAt", "isGraded") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: cway
--

COPY public."User" (id, name, email, "passwordHash", role, avatar, bio, phone, church, location, "preferredLanguage", "isVerified", "isBanned", "emailVerifyToken", "resetToken", "resetTokenExpiry", "googleId", "lastLoginAt", "lastLogoutAt", "createdAt", "updatedAt", "socialLinks", title, credentials, "yearsExperience", expertise, "notificationPrefs", "appActiveSeconds") FROM stdin;
\.


--
-- Name: ActivityLog ActivityLog_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT "ActivityLog_pkey" PRIMARY KEY (id);


--
-- Name: Announcement Announcement_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Announcement"
    ADD CONSTRAINT "Announcement_pkey" PRIMARY KEY (id);


--
-- Name: Answer Answer_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Answer"
    ADD CONSTRAINT "Answer_pkey" PRIMARY KEY (id);


--
-- Name: Assignment Assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Assignment"
    ADD CONSTRAINT "Assignment_pkey" PRIMARY KEY (id);


--
-- Name: AttendanceRecord AttendanceRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."AttendanceRecord"
    ADD CONSTRAINT "AttendanceRecord_pkey" PRIMARY KEY (id);


--
-- Name: AttendanceSession AttendanceSession_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."AttendanceSession"
    ADD CONSTRAINT "AttendanceSession_pkey" PRIMARY KEY (id);


--
-- Name: BlogPost BlogPost_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."BlogPost"
    ADD CONSTRAINT "BlogPost_pkey" PRIMARY KEY (id);


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (id);


--
-- Name: CertificateTemplate CertificateTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."CertificateTemplate"
    ADD CONSTRAINT "CertificateTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Certificate Certificate_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_pkey" PRIMARY KEY (id);


--
-- Name: Coupon Coupon_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Coupon"
    ADD CONSTRAINT "Coupon_pkey" PRIMARY KEY (id);


--
-- Name: CourseInvitation CourseInvitation_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."CourseInvitation"
    ADD CONSTRAINT "CourseInvitation_pkey" PRIMARY KEY (id);


--
-- Name: Course Course_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_pkey" PRIMARY KEY (id);


--
-- Name: Curriculum Curriculum_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Curriculum"
    ADD CONSTRAINT "Curriculum_pkey" PRIMARY KEY (id);


--
-- Name: DiscussionReply DiscussionReply_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."DiscussionReply"
    ADD CONSTRAINT "DiscussionReply_pkey" PRIMARY KEY (id);


--
-- Name: Discussion Discussion_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Discussion"
    ADD CONSTRAINT "Discussion_pkey" PRIMARY KEY (id);


--
-- Name: EmailTemplate EmailTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."EmailTemplate"
    ADD CONSTRAINT "EmailTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Enrollment Enrollment_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_pkey" PRIMARY KEY (id);


--
-- Name: ExtensionRequest ExtensionRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ExtensionRequest"
    ADD CONSTRAINT "ExtensionRequest_pkey" PRIMARY KEY (id);


--
-- Name: Extension Extension_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Extension"
    ADD CONSTRAINT "Extension_pkey" PRIMARY KEY (id);


--
-- Name: ForumPost ForumPost_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ForumPost"
    ADD CONSTRAINT "ForumPost_pkey" PRIMARY KEY (id);


--
-- Name: ForumReply ForumReply_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ForumReply"
    ADD CONSTRAINT "ForumReply_pkey" PRIMARY KEY (id);


--
-- Name: Forum Forum_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Forum"
    ADD CONSTRAINT "Forum_pkey" PRIMARY KEY (id);


--
-- Name: LessonProgress LessonProgress_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."LessonProgress"
    ADD CONSTRAINT "LessonProgress_pkey" PRIMARY KEY (id);


--
-- Name: Lesson Lesson_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Lesson"
    ADD CONSTRAINT "Lesson_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: Note Note_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Note"
    ADD CONSTRAINT "Note_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: ProgramApplication ProgramApplication_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ProgramApplication"
    ADD CONSTRAINT "ProgramApplication_pkey" PRIMARY KEY (id);


--
-- Name: ProgramEnrollment ProgramEnrollment_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ProgramEnrollment"
    ADD CONSTRAINT "ProgramEnrollment_pkey" PRIMARY KEY (id);


--
-- Name: Program Program_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Program"
    ADD CONSTRAINT "Program_pkey" PRIMARY KEY (id);


--
-- Name: Question Question_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_pkey" PRIMARY KEY (id);


--
-- Name: QuizAttempt QuizAttempt_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."QuizAttempt"
    ADD CONSTRAINT "QuizAttempt_pkey" PRIMARY KEY (id);


--
-- Name: Quiz Quiz_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Quiz"
    ADD CONSTRAINT "Quiz_pkey" PRIMARY KEY (id);


--
-- Name: ReadingMaterialProgress ReadingMaterialProgress_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ReadingMaterialProgress"
    ADD CONSTRAINT "ReadingMaterialProgress_pkey" PRIMARY KEY (id);


--
-- Name: ReadingMaterial ReadingMaterial_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ReadingMaterial"
    ADD CONSTRAINT "ReadingMaterial_pkey" PRIMARY KEY (id);


--
-- Name: ReferenceForm ReferenceForm_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ReferenceForm"
    ADD CONSTRAINT "ReferenceForm_pkey" PRIMARY KEY (id);


--
-- Name: Review Review_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_pkey" PRIMARY KEY (id);


--
-- Name: RubricCriteria RubricCriteria_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."RubricCriteria"
    ADD CONSTRAINT "RubricCriteria_pkey" PRIMARY KEY (id);


--
-- Name: RubricLevel RubricLevel_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."RubricLevel"
    ADD CONSTRAINT "RubricLevel_pkey" PRIMARY KEY (id);


--
-- Name: Rubric Rubric_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Rubric"
    ADD CONSTRAINT "Rubric_pkey" PRIMARY KEY (id);


--
-- Name: Section Section_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Section"
    ADD CONSTRAINT "Section_pkey" PRIMARY KEY (id);


--
-- Name: SiteSettings SiteSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."SiteSettings"
    ADD CONSTRAINT "SiteSettings_pkey" PRIMARY KEY (id);


--
-- Name: Sponsorship Sponsorship_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Sponsorship"
    ADD CONSTRAINT "Sponsorship_pkey" PRIMARY KEY (id);


--
-- Name: Submission Submission_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Submission"
    ADD CONSTRAINT "Submission_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: ActivityLog_action_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ActivityLog_action_idx" ON public."ActivityLog" USING btree (action);


--
-- Name: ActivityLog_createdAt_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ActivityLog_createdAt_idx" ON public."ActivityLog" USING btree ("createdAt");


--
-- Name: ActivityLog_resource_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ActivityLog_resource_idx" ON public."ActivityLog" USING btree (resource);


--
-- Name: ActivityLog_status_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ActivityLog_status_idx" ON public."ActivityLog" USING btree (status);


--
-- Name: ActivityLog_userId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ActivityLog_userId_idx" ON public."ActivityLog" USING btree ("userId");


--
-- Name: Announcement_authorId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Announcement_authorId_idx" ON public."Announcement" USING btree ("authorId");


--
-- Name: Announcement_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Announcement_courseId_idx" ON public."Announcement" USING btree ("courseId");


--
-- Name: Announcement_sectionId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Announcement_sectionId_idx" ON public."Announcement" USING btree ("sectionId");


--
-- Name: Answer_questionId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Answer_questionId_idx" ON public."Answer" USING btree ("questionId");


--
-- Name: Assignment_lessonId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Assignment_lessonId_key" ON public."Assignment" USING btree ("lessonId");


--
-- Name: Assignment_rubricId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Assignment_rubricId_idx" ON public."Assignment" USING btree ("rubricId");


--
-- Name: AttendanceRecord_sessionId_studentId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "AttendanceRecord_sessionId_studentId_key" ON public."AttendanceRecord" USING btree ("sessionId", "studentId");


--
-- Name: AttendanceRecord_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "AttendanceRecord_studentId_idx" ON public."AttendanceRecord" USING btree ("studentId");


--
-- Name: AttendanceSession_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "AttendanceSession_courseId_idx" ON public."AttendanceSession" USING btree ("courseId");


--
-- Name: AttendanceSession_sectionId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "AttendanceSession_sectionId_idx" ON public."AttendanceSession" USING btree ("sectionId");


--
-- Name: BlogPost_authorId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "BlogPost_authorId_idx" ON public."BlogPost" USING btree ("authorId");


--
-- Name: BlogPost_slug_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "BlogPost_slug_idx" ON public."BlogPost" USING btree (slug);


--
-- Name: BlogPost_slug_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "BlogPost_slug_key" ON public."BlogPost" USING btree (slug);


--
-- Name: Category_slug_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Category_slug_key" ON public."Category" USING btree (slug);


--
-- Name: Certificate_certificateNumber_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Certificate_certificateNumber_key" ON public."Certificate" USING btree ("certificateNumber");


--
-- Name: Certificate_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Certificate_courseId_idx" ON public."Certificate" USING btree ("courseId");


--
-- Name: Certificate_programId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Certificate_programId_idx" ON public."Certificate" USING btree ("programId");


--
-- Name: Certificate_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Certificate_studentId_idx" ON public."Certificate" USING btree ("studentId");


--
-- Name: Certificate_templateId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Certificate_templateId_idx" ON public."Certificate" USING btree ("templateId");


--
-- Name: Certificate_uniqueCode_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Certificate_uniqueCode_key" ON public."Certificate" USING btree ("uniqueCode");


--
-- Name: Coupon_code_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Coupon_code_key" ON public."Coupon" USING btree (code);


--
-- Name: Coupon_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Coupon_courseId_idx" ON public."Coupon" USING btree ("courseId");


--
-- Name: CourseInvitation_courseId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "CourseInvitation_courseId_key" ON public."CourseInvitation" USING btree ("courseId");


--
-- Name: CourseInvitation_instructorId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "CourseInvitation_instructorId_idx" ON public."CourseInvitation" USING btree ("instructorId");


--
-- Name: CourseInvitation_status_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "CourseInvitation_status_idx" ON public."CourseInvitation" USING btree (status);


--
-- Name: Course_categoryId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Course_categoryId_idx" ON public."Course" USING btree ("categoryId");


--
-- Name: Course_instructorId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Course_instructorId_idx" ON public."Course" USING btree ("instructorId");


--
-- Name: Course_isFeatured_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Course_isFeatured_idx" ON public."Course" USING btree ("isFeatured");


--
-- Name: Course_programId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Course_programId_idx" ON public."Course" USING btree ("programId");


--
-- Name: Course_slug_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Course_slug_idx" ON public."Course" USING btree (slug);


--
-- Name: Course_slug_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Course_slug_key" ON public."Course" USING btree (slug);


--
-- Name: Course_status_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Course_status_idx" ON public."Course" USING btree (status);


--
-- Name: Curriculum_courseId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Curriculum_courseId_key" ON public."Curriculum" USING btree ("courseId");


--
-- Name: DiscussionReply_authorId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "DiscussionReply_authorId_idx" ON public."DiscussionReply" USING btree ("authorId");


--
-- Name: DiscussionReply_discussionId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "DiscussionReply_discussionId_idx" ON public."DiscussionReply" USING btree ("discussionId");


--
-- Name: Discussion_authorId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Discussion_authorId_idx" ON public."Discussion" USING btree ("authorId");


--
-- Name: Discussion_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Discussion_courseId_idx" ON public."Discussion" USING btree ("courseId");


--
-- Name: Discussion_lessonId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Discussion_lessonId_idx" ON public."Discussion" USING btree ("lessonId");


--
-- Name: Discussion_sectionId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Discussion_sectionId_idx" ON public."Discussion" USING btree ("sectionId");


--
-- Name: EmailTemplate_name_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "EmailTemplate_name_key" ON public."EmailTemplate" USING btree (name);


--
-- Name: Enrollment_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Enrollment_courseId_idx" ON public."Enrollment" USING btree ("courseId");


--
-- Name: Enrollment_enrolledAt_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Enrollment_enrolledAt_idx" ON public."Enrollment" USING btree ("enrolledAt");


--
-- Name: Enrollment_paymentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Enrollment_paymentId_idx" ON public."Enrollment" USING btree ("paymentId");


--
-- Name: Enrollment_sponsorshipId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Enrollment_sponsorshipId_idx" ON public."Enrollment" USING btree ("sponsorshipId");


--
-- Name: Enrollment_status_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Enrollment_status_idx" ON public."Enrollment" USING btree (status);


--
-- Name: Enrollment_studentId_courseId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Enrollment_studentId_courseId_key" ON public."Enrollment" USING btree ("studentId", "courseId");


--
-- Name: Enrollment_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Enrollment_studentId_idx" ON public."Enrollment" USING btree ("studentId");


--
-- Name: ExtensionRequest_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ExtensionRequest_courseId_idx" ON public."ExtensionRequest" USING btree ("courseId");


--
-- Name: ExtensionRequest_itemId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ExtensionRequest_itemId_idx" ON public."ExtensionRequest" USING btree ("itemId");


--
-- Name: ExtensionRequest_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ExtensionRequest_studentId_idx" ON public."ExtensionRequest" USING btree ("studentId");


--
-- Name: Extension_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Extension_courseId_idx" ON public."Extension" USING btree ("courseId");


--
-- Name: Extension_itemId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Extension_itemId_idx" ON public."Extension" USING btree ("itemId");


--
-- Name: Extension_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Extension_studentId_idx" ON public."Extension" USING btree ("studentId");


--
-- Name: Extension_studentId_itemId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Extension_studentId_itemId_key" ON public."Extension" USING btree ("studentId", "itemId");


--
-- Name: ForumPost_authorId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ForumPost_authorId_idx" ON public."ForumPost" USING btree ("authorId");


--
-- Name: ForumPost_forumId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ForumPost_forumId_idx" ON public."ForumPost" USING btree ("forumId");


--
-- Name: ForumReply_authorId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ForumReply_authorId_idx" ON public."ForumReply" USING btree ("authorId");


--
-- Name: ForumReply_postId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ForumReply_postId_idx" ON public."ForumReply" USING btree ("postId");


--
-- Name: Forum_courseId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Forum_courseId_key" ON public."Forum" USING btree ("courseId");


--
-- Name: LessonProgress_enrollmentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "LessonProgress_enrollmentId_idx" ON public."LessonProgress" USING btree ("enrollmentId");


--
-- Name: LessonProgress_enrollmentId_lessonId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "LessonProgress_enrollmentId_lessonId_key" ON public."LessonProgress" USING btree ("enrollmentId", "lessonId");


--
-- Name: LessonProgress_lessonId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "LessonProgress_lessonId_idx" ON public."LessonProgress" USING btree ("lessonId");


--
-- Name: Lesson_sectionId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Lesson_sectionId_idx" ON public."Lesson" USING btree ("sectionId");


--
-- Name: Message_receiverId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Message_receiverId_idx" ON public."Message" USING btree ("receiverId");


--
-- Name: Message_senderId_receiverId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Message_senderId_receiverId_idx" ON public."Message" USING btree ("senderId", "receiverId");


--
-- Name: Note_lessonId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Note_lessonId_idx" ON public."Note" USING btree ("lessonId");


--
-- Name: Note_studentId_lessonId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Note_studentId_lessonId_key" ON public."Note" USING btree ("studentId", "lessonId");


--
-- Name: Notification_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Notification_userId_createdAt_idx" ON public."Notification" USING btree ("userId", "createdAt");


--
-- Name: Notification_userId_isRead_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Notification_userId_isRead_idx" ON public."Notification" USING btree ("userId", "isRead");


--
-- Name: Payment_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Payment_courseId_idx" ON public."Payment" USING btree ("courseId");


--
-- Name: Payment_status_createdAt_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Payment_status_createdAt_idx" ON public."Payment" USING btree (status, "createdAt");


--
-- Name: Payment_stripePaymentId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Payment_stripePaymentId_key" ON public."Payment" USING btree ("stripePaymentId");


--
-- Name: Payment_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Payment_studentId_idx" ON public."Payment" USING btree ("studentId");


--
-- Name: ProgramApplication_email_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ProgramApplication_email_idx" ON public."ProgramApplication" USING btree (email);


--
-- Name: ProgramApplication_programId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ProgramApplication_programId_idx" ON public."ProgramApplication" USING btree ("programId");


--
-- Name: ProgramApplication_reference1Token_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "ProgramApplication_reference1Token_key" ON public."ProgramApplication" USING btree ("reference1Token");


--
-- Name: ProgramApplication_reference2Token_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "ProgramApplication_reference2Token_key" ON public."ProgramApplication" USING btree ("reference2Token");


--
-- Name: ProgramEnrollment_programId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ProgramEnrollment_programId_idx" ON public."ProgramEnrollment" USING btree ("programId");


--
-- Name: ProgramEnrollment_studentId_programId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "ProgramEnrollment_studentId_programId_key" ON public."ProgramEnrollment" USING btree ("studentId", "programId");


--
-- Name: Program_status_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Program_status_idx" ON public."Program" USING btree (status);


--
-- Name: Question_quizId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Question_quizId_idx" ON public."Question" USING btree ("quizId");


--
-- Name: QuizAttempt_quizId_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "QuizAttempt_quizId_studentId_idx" ON public."QuizAttempt" USING btree ("quizId", "studentId");


--
-- Name: QuizAttempt_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "QuizAttempt_studentId_idx" ON public."QuizAttempt" USING btree ("studentId");


--
-- Name: Quiz_lessonId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Quiz_lessonId_key" ON public."Quiz" USING btree ("lessonId");


--
-- Name: Quiz_rubricId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Quiz_rubricId_idx" ON public."Quiz" USING btree ("rubricId");


--
-- Name: ReadingMaterialProgress_enrollmentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ReadingMaterialProgress_enrollmentId_idx" ON public."ReadingMaterialProgress" USING btree ("enrollmentId");


--
-- Name: ReadingMaterialProgress_enrollmentId_readingMaterialId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "ReadingMaterialProgress_enrollmentId_readingMaterialId_key" ON public."ReadingMaterialProgress" USING btree ("enrollmentId", "readingMaterialId");


--
-- Name: ReadingMaterialProgress_readingMaterialId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ReadingMaterialProgress_readingMaterialId_idx" ON public."ReadingMaterialProgress" USING btree ("readingMaterialId");


--
-- Name: ReadingMaterial_sectionId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "ReadingMaterial_sectionId_idx" ON public."ReadingMaterial" USING btree ("sectionId");


--
-- Name: ReferenceForm_applicationId_referenceIndex_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "ReferenceForm_applicationId_referenceIndex_key" ON public."ReferenceForm" USING btree ("applicationId", "referenceIndex");


--
-- Name: Review_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Review_courseId_idx" ON public."Review" USING btree ("courseId");


--
-- Name: Review_courseId_studentId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Review_courseId_studentId_key" ON public."Review" USING btree ("courseId", "studentId");


--
-- Name: Review_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Review_studentId_idx" ON public."Review" USING btree ("studentId");


--
-- Name: RubricCriteria_rubricId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "RubricCriteria_rubricId_idx" ON public."RubricCriteria" USING btree ("rubricId");


--
-- Name: RubricLevel_criteriaId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "RubricLevel_criteriaId_idx" ON public."RubricLevel" USING btree ("criteriaId");


--
-- Name: Rubric_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Rubric_courseId_idx" ON public."Rubric" USING btree ("courseId");


--
-- Name: Section_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Section_courseId_idx" ON public."Section" USING btree ("courseId");


--
-- Name: Sponsorship_courseId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Sponsorship_courseId_idx" ON public."Sponsorship" USING btree ("courseId");


--
-- Name: Sponsorship_stripePaymentId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Sponsorship_stripePaymentId_key" ON public."Sponsorship" USING btree ("stripePaymentId");


--
-- Name: Sponsorship_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Sponsorship_studentId_idx" ON public."Sponsorship" USING btree ("studentId");


--
-- Name: Submission_assignmentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Submission_assignmentId_idx" ON public."Submission" USING btree ("assignmentId");


--
-- Name: Submission_assignmentId_studentId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "Submission_assignmentId_studentId_key" ON public."Submission" USING btree ("assignmentId", "studentId");


--
-- Name: Submission_studentId_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "Submission_studentId_idx" ON public."Submission" USING btree ("studentId");


--
-- Name: User_createdAt_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "User_createdAt_idx" ON public."User" USING btree ("createdAt");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_googleId_key; Type: INDEX; Schema: public; Owner: cway
--

CREATE UNIQUE INDEX "User_googleId_key" ON public."User" USING btree ("googleId");


--
-- Name: User_role_idx; Type: INDEX; Schema: public; Owner: cway
--

CREATE INDEX "User_role_idx" ON public."User" USING btree (role);


--
-- Name: ActivityLog ActivityLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT "ActivityLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Announcement Announcement_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Announcement"
    ADD CONSTRAINT "Announcement_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Announcement Announcement_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Announcement"
    ADD CONSTRAINT "Announcement_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Announcement Announcement_sectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Announcement"
    ADD CONSTRAINT "Announcement_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES public."Section"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Answer Answer_questionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Answer"
    ADD CONSTRAINT "Answer_questionId_fkey" FOREIGN KEY ("questionId") REFERENCES public."Question"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Assignment Assignment_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Assignment"
    ADD CONSTRAINT "Assignment_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public."Lesson"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Assignment Assignment_rubricId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Assignment"
    ADD CONSTRAINT "Assignment_rubricId_fkey" FOREIGN KEY ("rubricId") REFERENCES public."Rubric"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AttendanceRecord AttendanceRecord_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."AttendanceRecord"
    ADD CONSTRAINT "AttendanceRecord_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."AttendanceSession"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AttendanceRecord AttendanceRecord_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."AttendanceRecord"
    ADD CONSTRAINT "AttendanceRecord_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AttendanceSession AttendanceSession_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."AttendanceSession"
    ADD CONSTRAINT "AttendanceSession_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AttendanceSession AttendanceSession_sectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."AttendanceSession"
    ADD CONSTRAINT "AttendanceSession_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES public."Section"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BlogPost BlogPost_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."BlogPost"
    ADD CONSTRAINT "BlogPost_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Category Category_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Certificate Certificate_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Certificate Certificate_programId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_programId_fkey" FOREIGN KEY ("programId") REFERENCES public."Program"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Certificate Certificate_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Certificate Certificate_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."CertificateTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Coupon Coupon_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Coupon"
    ADD CONSTRAINT "Coupon_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CourseInvitation CourseInvitation_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."CourseInvitation"
    ADD CONSTRAINT "CourseInvitation_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CourseInvitation CourseInvitation_instructorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."CourseInvitation"
    ADD CONSTRAINT "CourseInvitation_instructorId_fkey" FOREIGN KEY ("instructorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Course Course_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Course Course_instructorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_instructorId_fkey" FOREIGN KEY ("instructorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Course Course_programId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_programId_fkey" FOREIGN KEY ("programId") REFERENCES public."Program"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Curriculum Curriculum_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Curriculum"
    ADD CONSTRAINT "Curriculum_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DiscussionReply DiscussionReply_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."DiscussionReply"
    ADD CONSTRAINT "DiscussionReply_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DiscussionReply DiscussionReply_discussionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."DiscussionReply"
    ADD CONSTRAINT "DiscussionReply_discussionId_fkey" FOREIGN KEY ("discussionId") REFERENCES public."Discussion"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Discussion Discussion_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Discussion"
    ADD CONSTRAINT "Discussion_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Discussion Discussion_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Discussion"
    ADD CONSTRAINT "Discussion_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Discussion Discussion_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Discussion"
    ADD CONSTRAINT "Discussion_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public."Lesson"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Discussion Discussion_sectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Discussion"
    ADD CONSTRAINT "Discussion_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES public."Section"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Enrollment Enrollment_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Enrollment Enrollment_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public."Payment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Enrollment Enrollment_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ExtensionRequest ExtensionRequest_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ExtensionRequest"
    ADD CONSTRAINT "ExtensionRequest_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ExtensionRequest ExtensionRequest_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ExtensionRequest"
    ADD CONSTRAINT "ExtensionRequest_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Extension Extension_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Extension"
    ADD CONSTRAINT "Extension_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Extension Extension_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Extension"
    ADD CONSTRAINT "Extension_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ForumPost ForumPost_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ForumPost"
    ADD CONSTRAINT "ForumPost_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ForumPost ForumPost_forumId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ForumPost"
    ADD CONSTRAINT "ForumPost_forumId_fkey" FOREIGN KEY ("forumId") REFERENCES public."Forum"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ForumReply ForumReply_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ForumReply"
    ADD CONSTRAINT "ForumReply_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ForumReply ForumReply_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ForumReply"
    ADD CONSTRAINT "ForumReply_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."ForumPost"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Forum Forum_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Forum"
    ADD CONSTRAINT "Forum_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LessonProgress LessonProgress_enrollmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."LessonProgress"
    ADD CONSTRAINT "LessonProgress_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES public."Enrollment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LessonProgress LessonProgress_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."LessonProgress"
    ADD CONSTRAINT "LessonProgress_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public."Lesson"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Lesson Lesson_sectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Lesson"
    ADD CONSTRAINT "Lesson_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES public."Section"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Note Note_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Note"
    ADD CONSTRAINT "Note_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public."Lesson"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Note Note_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Note"
    ADD CONSTRAINT "Note_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProgramApplication ProgramApplication_programId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ProgramApplication"
    ADD CONSTRAINT "ProgramApplication_programId_fkey" FOREIGN KEY ("programId") REFERENCES public."Program"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProgramEnrollment ProgramEnrollment_programId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ProgramEnrollment"
    ADD CONSTRAINT "ProgramEnrollment_programId_fkey" FOREIGN KEY ("programId") REFERENCES public."Program"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProgramEnrollment ProgramEnrollment_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ProgramEnrollment"
    ADD CONSTRAINT "ProgramEnrollment_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Question Question_quizId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_quizId_fkey" FOREIGN KEY ("quizId") REFERENCES public."Quiz"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: QuizAttempt QuizAttempt_quizId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."QuizAttempt"
    ADD CONSTRAINT "QuizAttempt_quizId_fkey" FOREIGN KEY ("quizId") REFERENCES public."Quiz"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: QuizAttempt QuizAttempt_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."QuizAttempt"
    ADD CONSTRAINT "QuizAttempt_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Quiz Quiz_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Quiz"
    ADD CONSTRAINT "Quiz_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public."Lesson"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Quiz Quiz_rubricId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Quiz"
    ADD CONSTRAINT "Quiz_rubricId_fkey" FOREIGN KEY ("rubricId") REFERENCES public."Rubric"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ReadingMaterialProgress ReadingMaterialProgress_enrollmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ReadingMaterialProgress"
    ADD CONSTRAINT "ReadingMaterialProgress_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES public."Enrollment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ReadingMaterialProgress ReadingMaterialProgress_readingMaterialId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ReadingMaterialProgress"
    ADD CONSTRAINT "ReadingMaterialProgress_readingMaterialId_fkey" FOREIGN KEY ("readingMaterialId") REFERENCES public."ReadingMaterial"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ReadingMaterial ReadingMaterial_sectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ReadingMaterial"
    ADD CONSTRAINT "ReadingMaterial_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES public."Section"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ReferenceForm ReferenceForm_applicationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."ReferenceForm"
    ADD CONSTRAINT "ReferenceForm_applicationId_fkey" FOREIGN KEY ("applicationId") REFERENCES public."ProgramApplication"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Review Review_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Review Review_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RubricCriteria RubricCriteria_rubricId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."RubricCriteria"
    ADD CONSTRAINT "RubricCriteria_rubricId_fkey" FOREIGN KEY ("rubricId") REFERENCES public."Rubric"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RubricLevel RubricLevel_criteriaId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."RubricLevel"
    ADD CONSTRAINT "RubricLevel_criteriaId_fkey" FOREIGN KEY ("criteriaId") REFERENCES public."RubricCriteria"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Rubric Rubric_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Rubric"
    ADD CONSTRAINT "Rubric_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Section Section_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Section"
    ADD CONSTRAINT "Section_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Sponsorship Sponsorship_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Sponsorship"
    ADD CONSTRAINT "Sponsorship_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Submission Submission_assignmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Submission"
    ADD CONSTRAINT "Submission_assignmentId_fkey" FOREIGN KEY ("assignmentId") REFERENCES public."Assignment"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Submission Submission_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cway
--

ALTER TABLE ONLY public."Submission"
    ADD CONSTRAINT "Submission_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: cway
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict XrNYLkkEPlXm5Tnv7pWq2jkJeG0wbButLhTf95qdujLt0IFWLsEav8usdbdW8p4

